# app/config.py

import os

USE_LOCALSTACK = True
AWS_ENDPOINT = "http://localhost:4566"  # NOT localhost
AWS_REGION = "us-east-1"
S3_BUCKET = "images-bucket"
DYNAMO_TABLE = "images_metadata"

