import os
import boto3
from app.config import DYNAMO_TABLE

AWS_ENDPOINT = os.environ.get("AWS_ENDPOINT", "http://localstack:4566")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

def get_s3_client():
    return boto3.client("s3", region_name=AWS_REGION, endpoint_url=AWS_ENDPOINT)

def get_dynamo_table():
    dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION, endpoint_url=AWS_ENDPOINT)
    return dynamodb.Table(DYNAMO_TABLE)


